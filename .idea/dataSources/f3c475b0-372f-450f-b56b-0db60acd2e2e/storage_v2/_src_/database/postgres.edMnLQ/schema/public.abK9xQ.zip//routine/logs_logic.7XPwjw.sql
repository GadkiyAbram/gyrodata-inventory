create function logs_logic() returns trigger
    language plpgsql
as
$$
BEGIN
		INSERT INTO employees_logs (message) VALUES (CONCAT('New employee ', NEW.name, ' added'));
        RETURN NEW;
	END;
$$;

alter function logs_logic() owner to postgres;

